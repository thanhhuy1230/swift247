# Hướng dẫn chạy Swift247 (Backend + Frontend đã kết nối)

## 1. Chạy Backend

```bash
cd swift247-backend-connected
npm install
```

Kiểm tra file `.env` (đã có sẵn), sửa lại thông tin PostgreSQL cho đúng máy của bạn:

```
PGHOST=127.0.0.1
PGPORT=5432
PGDATABASE=swift247
PGUSER=postgres
PGPASSWORD=<mật khẩu Postgres của bạn>
```

Chạy migration (tạo bảng) rồi khởi động server:

```bash
npm run migrate
npm run dev
```

Backend sẽ chạy tại `http://localhost:4000`. Kiểm tra bằng:
```bash
curl http://localhost:4000/health
```

## 2. Chạy Frontend

```bash
cd swift247-frontend-connected
npm install
```

Mở file `.env`, đảm bảo trỏ đúng địa chỉ backend:

- Chạy `npm run web` trên **cùng máy** với backend: giữ mặc định `EXPO_PUBLIC_API_URL=http://localhost:4000`.
- Chạy trên **điện thoại thật** qua Expo Go: đổi thành IP LAN máy tính, ví dụ `EXPO_PUBLIC_API_URL=http://192.168.1.10:4000`.
- Chạy trên **Android Emulator**: dùng `http://10.0.2.2:4000`.

Khởi động app:
```bash
npm run web       # chạy trên trình duyệt (đầy đủ luồng OTP + đăng ký DN)
# hoặc
npm start         # quét QR mở bằng Expo Go trên điện thoại (màn hình email/mật khẩu)
```

## 3. Những gì đã được kết nối thật (test bằng tay, chạy được)

- Đăng nhập cá nhân bằng OTP (web): `POST /api/auth/otp/request` → `POST /api/auth/otp/verify`
- Đăng ký tài khoản doanh nghiệp (web): `POST /api/auth/register/business`
- Đăng nhập email/mật khẩu (mobile — `app/(auth)/login.tsx`): `POST /api/auth/login`
- Lưu token đăng nhập, tự khôi phục phiên khi mở lại app
- Đăng xuất (trong Hồ sơ) → `POST /api/auth/logout`

## 4. Giới hạn cần biết

- Màn hình đăng nhập doanh nghiệp trên bản web chỉ có ô "mã khách hàng", **không có ô mật khẩu** trong khi backend bắt buộc `identifier + password`. Vì yêu cầu không sửa giao diện, bước này tạm thời chỉ điều hướng demo, chưa gọi API thật. Muốn dùng thật, đăng nhập bằng email/mật khẩu ở bản mobile, hoặc nhờ bổ sung ô mật khẩu vào form web.
- Backend hiện chỉ có module xác thực (Auth). Các màn hình đơn hàng, thanh toán, đặt vận đơn, tin tức, thông báo... vẫn là giao diện tĩnh vì backend chưa có API tương ứng.
- OTP ở môi trường dev được in ra **console log** của backend (chưa nối SMS Gateway thật) — mở terminal chạy `npm run dev` để xem mã OTP khi test.
